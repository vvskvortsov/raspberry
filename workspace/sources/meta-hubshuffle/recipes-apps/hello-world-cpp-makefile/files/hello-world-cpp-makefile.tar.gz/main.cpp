#include <iostream>
#include <cstdlib>

int main() {
	std::cout << "Hello World CPP!!! " << std::endl;
	return EXIT_SUCCESS;
}
